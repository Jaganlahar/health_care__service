# Contact Buttons Plugin

A plugin based on jQuery to add contact buttons to your website.

Licensed under the MIT license:  
http://www.opensource.org/licenses/MIT

Copyright 2015, José Gonçalves.